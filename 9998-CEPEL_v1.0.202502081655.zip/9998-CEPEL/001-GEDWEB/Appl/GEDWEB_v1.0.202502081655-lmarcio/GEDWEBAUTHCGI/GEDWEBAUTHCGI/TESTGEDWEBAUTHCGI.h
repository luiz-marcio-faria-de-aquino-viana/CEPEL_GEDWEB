/*
* Copyright(C) TLMV Consultoria e Sistemas EIRELI. Todos os direitos reservados.
*
* TESTGEDWEBAUTHCGI.h
* Autor:
*   Luiz Marcio Faria de Aquino Viana, Pos-D.Sc. - Engenheiro, 08/02/2025
*   Unidade: Universidade do Estado do Rio de Janeiro
*   Curso: Engenharia Eletrica, Enfase em Engenharia de Sistemas e Computa��o
*   Unico Socio e Administrador da Empresa - Desde: 02/08/2000
*
* Revisoes: ...
*
*/

#pragma once

#ifndef __TESTGEDWEBAUTHCGI_H
#define __TESTGEDWEBAUTHCGI_H									(TCHAR*)"__TESTGEDWEBAUTHCGI_H"

int testApp(int argc, TCHAR* argv[]);

#endif
